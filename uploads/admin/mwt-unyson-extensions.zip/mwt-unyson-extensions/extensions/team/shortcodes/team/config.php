<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Team', 'mwtemplates' ),
		'description' => esc_html__( 'Team various views', 'mwtemplates' ),
		'tab'         => esc_html__( 'Widgets', 'mwtemplates' )
	)
);
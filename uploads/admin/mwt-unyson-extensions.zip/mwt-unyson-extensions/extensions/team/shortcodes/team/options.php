<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$ext_team_settings = fw()->extensions->get( 'team' )->get_settings();
$taxonomy = $ext_team_settings['taxonomy_name'];

$options = array(
	'number'        => array(
		'type'       => 'slider',
		'value'      => 6,
		'properties' => array(
			'min'  => 1,
			'max'  => 48,
			'step' => 1, // Set slider step. Always > 0. Could be fractional.

		),
		'label'      => esc_html__( 'Items number', 'mwtemplates' ),
		'desc'       => esc_html__( 'Number of posts to display', 'mwtemplates' ),
	),
	'margin'        => array(
		'label'   => esc_html__( 'Horizontal item margin (px)', 'mwtemplates' ),
		'desc'    => esc_html__( 'Select horizontal item margin', 'mwtemplates' ),
		'value'   => '30',
		'type'    => 'select',
		'choices' => array(
			'0'  => esc_html__( '0', 'mwtemplates' ),
			'1'  => esc_html__( '1px', 'mwtemplates' ),
			'2'  => esc_html__( '2px', 'mwtemplates' ),
			'10' => esc_html__( '10px', 'mwtemplates' ),
			'30' => esc_html__( '30px', 'mwtemplates' ),
		)
	),
	'layout'        => array(
		'label'   => esc_html__( 'Layout', 'mwtemplates' ),
		'desc'    => esc_html__( 'Choose layout', 'mwtemplates' ),
		'value'   => 'carousel',
		'type'    => 'select',
		'choices' => array(
			'carousel' => esc_html__( 'Carousel', 'mwtemplates' ),
			'isotope'  => esc_html__( 'Masonry Grid', 'mwtemplates' ),
		)
	),
	'responsive_lg' => array(
		'label'   => esc_html__( 'Columns on large screens', 'mwtemplates' ),
		'desc'    => esc_html__( 'Select items number on wide screens (>1200px)', 'mwtemplates' ),
		'value'   => '4',
		'type'    => 'select',
		'choices' => array(
			'1' => esc_html__( '1', 'mwtemplates' ),
			'2' => esc_html__( '2', 'mwtemplates' ),
			'3' => esc_html__( '3', 'mwtemplates' ),
			'4' => esc_html__( '4', 'mwtemplates' ),
			'6' => esc_html__( '6', 'mwtemplates' ),
		)
	),
	'responsive_md' => array(
		'label'   => esc_html__( 'Columns on middle screens', 'mwtemplates' ),
		'desc'    => esc_html__( 'Select items number on middle screens (>992px)', 'mwtemplates' ),
		'value'   => '3',
		'type'    => 'select',
		'choices' => array(
			'1' => esc_html__( '1', 'mwtemplates' ),
			'2' => esc_html__( '2', 'mwtemplates' ),
			'3' => esc_html__( '3', 'mwtemplates' ),
			'4' => esc_html__( '4', 'mwtemplates' ),
			'6' => esc_html__( '6', 'mwtemplates' ),
		)
	),
	'responsive_sm' => array(
		'label'   => esc_html__( 'Columns on small screens', 'mwtemplates' ),
		'desc'    => esc_html__( 'Select items number on small screens (>768px)', 'mwtemplates' ),
		'value'   => '2',
		'type'    => 'select',
		'choices' => array(
			'1' => esc_html__( '1', 'mwtemplates' ),
			'2' => esc_html__( '2', 'mwtemplates' ),
			'3' => esc_html__( '3', 'mwtemplates' ),
			'4' => esc_html__( '4', 'mwtemplates' ),
			'6' => esc_html__( '6', 'mwtemplates' ),
		)
	),
	'responsive_xs' => array(
		'label'   => esc_html__( 'Columns on extra small screens', 'mwtemplates' ),
		'desc'    => esc_html__( 'Select items number on extra small screens (<767px)', 'mwtemplates' ),
		'value'   => '1',
		'type'    => 'select',
		'choices' => array(
			'1' => esc_html__( '1', 'mwtemplates' ),
			'2' => esc_html__( '2', 'mwtemplates' ),
			'3' => esc_html__( '3', 'mwtemplates' ),
			'4' => esc_html__( '4', 'mwtemplates' ),
			'6' => esc_html__( '6', 'mwtemplates' ),
		)
	),
	'show_filters'  => array(
		'type'         => 'switch',
		'value'        => false,
		'label'        => esc_html__( 'Show filters', 'mwtemplates' ),
		'desc'         => esc_html__( 'Hide or show categories filters', 'mwtemplates' ),
		'left-choice'  => array(
			'value' => false,
			'label' => esc_html__( 'No', 'mwtemplates' ),
		),
		'right-choice' => array(
			'value' => true,
			'label' => esc_html__( 'Yes', 'mwtemplates' ),
		),
	),
	'cat' => array(
		'type'  => 'multi-select',
		'label' => esc_html__('Select categories', 'mwtemplates'),
		'desc'  => esc_html__('You can select one or more categories', 'mwtemplates'),
		'population' => 'taxonomy',
		'source' => $taxonomy,
		'prepopulate' => 10,
		'limit' => 100,
	)
);